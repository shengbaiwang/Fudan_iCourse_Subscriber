# iCourse 正式图标：秩序成为海浪

这版已被选定为 iCourse 的统一图标，后续应用入口沿用。

- icourse-approved.png：选定原图。
- icourse-icon.svg：可编辑的贝塞尔曲线与矢量渐变，可任意缩放。
- icourse-icon-1024.png / 512.png / 192.png：从选定原图导出的应用图标。
- apple-touch-icon.png：180 像素，主屏幕快捷方式。
- favicon.svg / favicon.ico / favicon-32.png / favicon-16.png：浏览器页签。
- comparison.png：原图、矢量版与小尺寸对比。

矢量版重绘轮廓、分层和渐变，平滑渐变代替原图的细微位图纹理。原生应用使用完整方形 PNG，由平台添加遮罩；网页圆角通过 CSS 添加。

设计意象来自 Anne Carson 的 Short Talk on the Total Collection：蓝色层次从整齐排列上涌为海浪。
